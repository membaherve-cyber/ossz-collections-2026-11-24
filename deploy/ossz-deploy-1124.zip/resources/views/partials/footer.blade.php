@php
    $settings = \App\Support\Settings::all();
    $loc = locale();
@endphp

<footer class="mt-24 border-t border-line bg-paper">
    <div class="wrap grid gap-12 py-16 md:grid-cols-4">
        {{-- Brand info --}}
        <div class="md:col-span-1">
            <div aria-label="OSSZ Collections" role="img" style="width:110px;height:40px;background-image:url(/logo-ossz.png);background-size:contain;background-repeat:no-repeat;background-position:left center"></div>
            <p class="mt-4 text-sm leading-relaxed text-ink-soft">
                {{ t('footer.tag') }}
            </p>
            <p class="mt-4 text-sm text-muted">{{ $settings['store_address'] ?? 'Douala, Cameroon' }}</p>
            <p class="mt-1 text-sm text-muted">{{ $settings['business_hours'] ?? 'Mon–Sat: 09:00 – 19:00' }}</p>
            <a href="https://wa.me/237694068219" target="_blank" rel="noreferrer" class="mt-2 flex items-center gap-2 text-sm text-muted hover:text-ink">
                <svg class="h-4 w-4 shrink-0" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
                </svg>
                +237 694 068 219
            </a>
            <a href="https://wa.me/237651468831" target="_blank" rel="noreferrer" class="mt-1 flex items-center gap-2 text-sm text-muted hover:text-ink">
                <svg class="h-4 w-4 shrink-0" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
                </svg>
                +237 651 468 831
            </a>
            <a href="mailto:{{ $settings['contact_email'] ?? 'info@osszcollection.com' }}" class="mt-1 flex items-center gap-2 text-sm text-muted hover:text-ink">
                <svg class="h-4 w-4 shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <rect width="20" height="16" x="2" y="4" rx="2"/><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/>
                </svg>
                {{ $settings['contact_email'] ?? 'info@osszcollection.com' }}
            </a>
            <div class="mt-3 flex gap-4">
                <a href="https://www.facebook.com/OSSZCollection" target="_blank" rel="noreferrer" class="text-muted hover:text-ink" aria-label="Facebook">
                    <svg class="h-5 w-5" fill="currentColor" viewBox="0 0 24 24"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>
                </a>
                <a href="https://www.instagram.com/theossz__" target="_blank" rel="noreferrer" class="text-muted hover:text-ink" aria-label="Instagram">
                    <svg class="h-5 w-5" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 100 12.324 6.162 6.162 0 000-12.324zM12 16a4 4 0 110-8 4 4 0 010 8zm6.406-11.845a1.44 1.44 0 100 2.881 1.44 1.44 0 000-2.881z"/></svg>
                </a>
            </div>
        </div>

        {{-- Shop --}}
        <div>
            <p class="eyebrow">{{ t('footer.shop') }}</p>
            <ul class="mt-4 space-y-2 text-sm text-ink-soft">
                <li><a class="link-underline" href="{{ route('shop') }}">{{ t('footer.allPieces') }}</a></li>
                <li><a class="link-underline" href="{{ route('collections.index') }}">{{ t('nav.collections') }}</a></li>
                <li><a class="link-underline" href="{{ route('lookbook') }}">{{ t('nav.lookbook') }}</a></li>
                <li><a class="link-underline" href="{{ route('appointments') }}">{{ t('home.bookCta') }}</a></li>
            </ul>
        </div>

        {{-- Client Care --}}
        <div>
            <p class="eyebrow">{{ t('footer.care') }}</p>
            <ul class="mt-4 space-y-2 text-sm text-ink-soft">
                <li><a class="link-underline" href="{{ route('faq') }}">{{ t('footer.faqLink') }}</a></li>
                <li><a class="link-underline" href="{{ route('size-guide') }}">{{ t('pdp.sizeGuide') }}</a></li>
                <li><a class="link-underline" href="{{ route('contact') }}">{{ t('footer.contactLink') }}</a></li>
                <li><a class="link-underline" href="{{ url('/order-lookup') }}">{{ t('footer.trackLink') }}</a></li>
                <li><a class="link-underline" href="{{ route('account.home') }}">{{ t('footer.accountLink') }}</a></li>
            </ul>
        </div>

        {{-- Newsletter --}}
        <div>
            <p class="eyebrow">{{ t('footer.letter') }}</p>
            <p class="mt-4 text-sm text-ink-soft">
                {{ t('footer.letterBody') }}
            </p>
            <form action="{{ route('newsletter') }}" method="POST" class="mt-4 flex flex-col gap-2">
                @csrf
                <div class="flex gap-2">
                    <input type="email" name="email" required placeholder="{{ t('footer.newsletterPlaceholder') }}"
                           class="field text-xs flex-1">
                    <button type="submit" class="btn btn-primary btn-sm whitespace-nowrap">{{ t('footer.subscribe') }}</button>
                </div>
            </form>
        </div>
    </div>

    {{-- Sub-footer bar --}}
    <div class="border-t border-line">
        <div class="wrap flex flex-col gap-2 py-6 text-xs text-muted md:flex-row md:items-center md:justify-between">
            <p>© {{ date('Y') }} OSSZ Collections · Douala, Cameroon</p>
            <p class="tracking-[0.14em] uppercase">
                MTN MoMo · Orange Money · Visa · Mastercard
            </p>
        </div>
    </div>
</footer>
